from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import googlemaps


app = FastAPI()

# Crée une classe pour les données de requête
class EmissionRequest(BaseModel):
    ville_depart: str
    ville_arrivee: str
    moyen_de_transport: str


API_KEY = "CLE_API_GOOGLE_MAPS"
gmaps = googlemaps.Client(key=API_KEY)

class Carbone:
    def __init__(self, ville_depart, ville_arrivee, moyen_de_transport):
        self.depart = ville_depart
        self.arrivee = ville_arrivee
        self.moyen_de_transport = moyen_de_transport

    def obtenir_distance(self):
        modes = {
            "aérien": "driving",
            "ferroviaire": "transit",
            "routier": "driving"
        }

        if self.moyen_de_transport not in modes:
            raise HTTPException(status_code=400, detail="Moyen de transport invalide.")

        directions_result = gmaps.directions(
            self.depart,
            self.arrivee,
            mode=modes[self.moyen_de_transport],
            units="metric"
        )

        if not directions_result:
            raise HTTPException(status_code=404, detail="Impossible de calculer la distance.")

        distance = directions_result[0]['legs'][0]['distance']['value'] / 1000  
        return distance

    def calcul_emission(self):
        distance = self.obtenir_distance()
        coefficients = {"aérien": 152, "ferroviaire": 2.36,  "routier": 29.5}
        coefficient = coefficients.get(self.moyen_de_transport)
        emission = round(distance * coefficient,3)
        formule = f"{distance} km * {coefficient} gCO2/passager.km"
        return emission, formule

    def recommandations(self, emission):
        if emission > 1000:
            return "Vos émissions sont élevées. Pensez à des alternatives plus écologiques comme le train ou le covoiturage."
        elif 500 < emission <= 1000:
            return "Les émissions sont modérées. Essayez d'utiliser des moyens de transport moins polluants ou de compenser vos émissions."
        else:
            return "Vos émissions sont relativement faibles, mais vous pouvez toujours opter pour des moyens de transport plus écologiques ou réduire votre impact en voyageant moins souvent."

@app.post("/emission/")
def calculer_emission(request: EmissionRequest):
    carbone = Carbone(request.ville_depart, request.ville_arrivee, request.moyen_de_transport)
    emission, formule = carbone.calcul_emission()
    recommandation = carbone.recommandations(emission)
    
    return {
        "emission": emission,
        "formule_calcul": formule,
        "recommandations": recommandation
    }
