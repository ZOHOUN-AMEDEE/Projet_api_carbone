from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from geopy.geocoders import Nominatim
from geopy.distance import geodesic


app = FastAPI()


class EmissionRequest(BaseModel):
    ville_depart: str
    ville_arrivee: str
    moyen_de_transport: str

class Carbone:
    def __init__(self, ville_depart, ville_arrivee, moyen_de_transport):
        self.depart = ville_depart
        self.arrivee = ville_arrivee
        self.moyen_de_transport = moyen_de_transport

    def obtenir_coordonnees(self, ville):
        geolocator = Nominatim(user_agent="Carbone")
        location = geolocator.geocode(ville)
        if location is None:
            raise HTTPException(status_code=404, detail=f"Ville '{ville}' introuvable.")
        return (location.latitude, location.longitude)

    def obtenir_distance(self):
        coordonnees_depart = self.obtenir_coordonnees(self.depart)
        coordonnees_arrivee = self.obtenir_coordonnees(self.arrivee)
        distance = geodesic(coordonnees_depart, coordonnees_arrivee).kilometers
        return distance

    def calcul_emission(self):
        distance = self.obtenir_distance()
        coefficients = {"aerien": 152, "ferroviaire": 2.36, "maritime": 230, "routier": 29.5}
        coefficient = coefficients.get(self.moyen_de_transport)
        emission = round(distance * coefficient,3)
        formule = f"{distance} km * {coefficient} gCO2/km"
        return emission, formule

    def recommandations(self, emission):
        if emission > 1000:
            return "Vos émissions sont élevées. Pensez à des alternatives plus écologiques comme le train ou le covoiturage."
        elif 500 < emission <= 1000:
            return "Les émissions sont modérées. Essayez d'utiliser des moyens de transport moins polluants ou de compenser vos émissions."
        else:
            return "Vos émissions sont relativement faibles, mais vous pouvez toujours opter pour des moyens de transport plus écologiques ou réduire votre impact en voyageant moins souvent."

@app.post("/emission/")
def calculer_emission(request: EmissionRequest):
    carbone = Carbone(request.ville_depart, request.ville_arrivee, request.moyen_de_transport)
    emission, formule = carbone.calcul_emission()
    recommandation = carbone.recommandations(emission)
    
    return {
        "emission": emission,
        "formule_calcul": formule,
        "recommandations": recommandation
    }
